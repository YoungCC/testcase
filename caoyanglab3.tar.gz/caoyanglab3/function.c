/**************************************************************************************************/
/* Copyright (C) SoftwareDesign@USTC, 2014                                                        */
/*                                                                                                */
/*  FILE NAME             :  function.c                                                           */
/*  PRINCIPAL AUTHOR      :  Caoyang                                                              */
/*  PRINCIPAL AUTHOR ID   :  JG14225028                                                           */
/*  SUBSYSTEM NAME        :  function                                                             */
/*  MODULE NAME           :  function                                                             */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/29                                                           */
/*  DESCRIPTION           :  This is a menu operation program                                     */
/**************************************************************************************************/

/*
 * Revision 
 *
 * Created by Caoyang, 2014/09/29
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
#include "linkTable.h"

#define CMD_MAX_LEN 128
#define FAILURE -1
#define SUCCESS 0

char pInputCmd[CMD_MAX_LEN];
char * deleteCmd;
int POP = 0;
/*command struct*/
typedef struct CmdNode
{
    tLinkNode *pNext;
    char* cmd;
    char* desc;
    int (*handler)();
} tCmdNode;

/*menu struct*/
struct Menu
{
    tLinkTable *pMenuHead;
};

/*create a menu*/
tMenu* CreateMenu()
{
    tMenu *pNewMenu = (tMenu*)malloc(sizeof(tMenu));
    if(pNewMenu == NULL)
    {
        return NULL;
    }
    tLinkTable *pNewLinkTable = CreateLinkTable();
    pNewMenu->pMenuHead = pNewLinkTable;
    return pNewMenu;
}

/*create linked list node*/
tCmdNode* CreateCmdNode(char* pNodeCmd, char* pNodeDesc, int (*pNodehand)())
{
    tCmdNode *pNewNode;
    pNewNode = (tCmdNode*)malloc(sizeof(tCmdNode));
    if(pNewNode == NULL)
    {
        printf("Command node created failed!\n");
        return NULL;
    }
    else
    {
        pNewNode->cmd = pNodeCmd;
        pNewNode->desc = pNodeDesc;
        pNewNode->handler = pNodehand;
    }
    return pNewNode;
}

/*add a command into menu*/
int AddCommand(tMenu *pMenu, char* pCom, char* pDesc, int (*handler)())
{
    if(pMenu == NULL || pCom == NULL || pDesc == NULL)
    {
        return FAILURE;
    }
    AddLinkNode(pMenu->pMenuHead, (tLinkNode *)CreateCmdNode(pCom, pDesc, handler));
    return SUCCESS;
}

/*print all commands and their functions on screen*/
int ShowAllInformation(tMenu *pMenu)
{
    if(pMenu == NULL)
    {
        return FAILURE;
    }
    tLinkTable *pLinkTable = pMenu->pMenuHead;
    if(pLinkTable->linkNodeSize == 0)
    {
        printf("There is no command.\n");
        return FAILURE;
    }
    tCmdNode *pThisCmdNode;
    pThisCmdNode = (tCmdNode *)GetLinkTableFirst(pLinkTable);
    while(pThisCmdNode != NULL)
    {
        printf("%s-------%s\n", pThisCmdNode->cmd, pThisCmdNode->desc);
        pThisCmdNode = (tCmdNode *)GetNextLinkNode(pLinkTable, (tLinkNode *)pThisCmdNode);
    }
    return SUCCESS;
}

/*the condition of search the matched com*/
int InputCondition(tLinkNode *pLinkNode)
{
    tCmdNode *pNode = (tCmdNode *)pLinkNode;
    if(!strcmp(pNode->cmd, pInputCmd))
    {
        return FAILURE;  
    }
    return SUCCESS;	       
}

/*start the menu program*/
void MenuStart(tMenu *pMenu)
{
    ShowAllInformation(pMenu);
    tCmdNode *pThisNode;
    while(1)
    {
        if(pMenu == NULL)
        {
            break;
        }
        printf("\nPlease enter a command:");
        scanf("%s", pInputCmd);
        if((pThisNode = (tCmdNode *)SearchLinkNode(pMenu->pMenuHead, InputCondition)) != NULL)
        {
            if(pThisNode->handler != NULL)
            {
                pThisNode->handler(pMenu);
            }
        }
        else
        {
            printf("Not exist!\n");
	    continue;
        }
        if(POP)
        {
            POP = 0;
            break;           
        } 
    }
}

/*stop the menu program*/
int MenuStop(tMenu *pMenu)
{
    if(pMenu == NULL)
    {
        return FAILURE;
    }
    printf("Exit success!\n\n");
    POP = 1;
    return SUCCESS;
}

/*the condition of delete the matched com*/
int DeleteCondition(tLinkNode *pLinkNode)
{
    tCmdNode *pNode = (tCmdNode *)pLinkNode;
    if(!strcmp(pNode->cmd, deleteCmd))
    {
        return FAILURE;
    }
    return SUCCESS;
}

/*delete command named pCom*/
int DeleteCommand(tMenu *pMenu, char* pCom)
{
    if(pMenu == NULL || pCom == NULL)
    {
        return FAILURE;
    }
    deleteCmd = pCom;
    tLinkNode *pLinkNode = SearchLinkNode(pMenu->pMenuHead, DeleteCondition);
    if(!DeleteLinkNode(pMenu->pMenuHead, pLinkNode))
    {
        printf("Delete command (%s) success!\n", pCom);
        return SUCCESS;
    }
    else
    {
        printf("Delete command (%s) failed!\n", pCom);
        return FAILURE;
    }
}

/*delete menu*/
int DeleteMenu(tMenu *pMenu)
{
    if(pMenu == NULL)
    {
        return FAILURE;
    }
    if(!DeleteLinkTable(pMenu->pMenuHead))
    {
        printf("Delete menu success!\n");
        free(pMenu);
        return SUCCESS;
    }
    else
    {
        printf("Delete menu failed!\n");
        return FAILURE;
    }
}


/**************************************************************************************************/
/* Copyright (C) SoftwareDesign@USTC, 2014                                                        */
/*                                                                                                */
/*  FILE NAME             :  linktabe.c                                                           */
/*  PRINCIPAL AUTHOR      :  Caoyang                                                              */
/*  PRINCIPAL AUTHOR ID   :  JG14225028                                                           */
/*  SUBSYSTEM NAME        :  LinkTable                                                            */
/*  MODULE NAME           :  LinkTable                                                            */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/20                                                           */
/*  DESCRIPTION           :  interface of Link Table                                              */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Caoyang,2014/09/20
 * Provide right Callback interface by Caoyang,2014/09/20 
 *
 */

#include<stdio.h>
#include<stdlib.h>
#include"linkTable.h"

/*
 * Create a LinkTable
 */
tLinkTable* CreateLinkTable()
{
    tLinkTable *pLinkTable = (tLinkTable*)malloc(sizeof(tLinkTable));
    if(pLinkTable == NULL)
    {
        return NULL;
    }
    tLinkNode *pHeadNode = (tLinkNode*)malloc(sizeof(tLinkNode));
    pHeadNode->pNext = NULL;
    pLinkTable->pHead = pHeadNode;
    pLinkTable->pTail = pHeadNode;
    pLinkTable->linkNodeSize = 0;
    return pLinkTable;
}

/*
 * Delete a LinkTable
 */
int DeleteLinkTable(tLinkTable *pLinkTable)
{
    if(pLinkTable == NULL)
    {
        printf("Not exist.\n");
        return -1;
    }
    tLinkNode *pThisNode;
    pThisNode = pLinkTable->pHead->pNext;
    while(pThisNode != NULL)
    {
        tLinkNode *pFreeNode;
        pLinkTable->pHead->pNext = pThisNode->pNext;
        pFreeNode = pThisNode;
        pThisNode = pThisNode->pNext;
        pFreeNode->pNext = NULL;
        free(pFreeNode);
    }
    pLinkTable->pHead = NULL;
    pLinkTable->pTail = NULL;
    pLinkTable->linkNodeSize = -1;
    free(pLinkTable);
    return 0;
}

/*
 * Add a LinkTableNode to LinkTable
 */
int AddLinkNode(tLinkTable *pLinkTable, tLinkNode *pAddNode)
{
    if(pLinkTable == NULL || pAddNode == NULL)
    {
        printf("Not exist.\n");
        return -1;
    }
    if(pLinkTable->linkNodeSize == 0)
    {
        pLinkTable->pHead->pNext = pAddNode;
        pAddNode->pNext = NULL;
        pLinkTable->pTail = pAddNode;
    }
    else
    {
        pAddNode->pNext = pLinkTable->pHead->pNext;
        pLinkTable->pHead->pNext = pAddNode;
    }
    pLinkTable->linkNodeSize++;
    return 0;
}

/*
 * Delete a LinkTableNode from LinkTable
 */
int DeleteLinkNode(tLinkTable *pLinkTable, tLinkNode *pNode)
{
    if(pLinkTable == NULL || pNode == NULL)
    {
        printf("Not exist.\n");
        return -1;
    }
    tLinkNode *pThisNode;
    tLinkNode *pBeforeNode;
    pThisNode = pLinkTable->pHead->pNext;
    pBeforeNode = pLinkTable->pHead;
    while(pThisNode != NULL)
    {
        if(pThisNode == pNode)
        {
            pBeforeNode->pNext = pThisNode->pNext;
            if(pThisNode->pNext == NULL)
            {
                pLinkTable->pTail = pBeforeNode;
            }
            pThisNode->pNext = NULL;
            free(pThisNode);
            pLinkTable->linkNodeSize--;
            return 0;
        }
        pBeforeNode = pThisNode;
        pThisNode = pThisNode->pNext;
    }
    printf("None to delete.\n");
    return -1;
}

/*
 * Search a LinkTableNode from LinkTable
 * int Conditon(tLinkTableNode * pNode);
 */
tLinkNode* SearchLinkNode(tLinkTable *pLinkTable, int Condition(tLinkNode *pNode))
{
    if(pLinkTable == NULL || Condition == NULL)
    {
        printf("Not exist.\n");
        return NULL;
    }
    tLinkNode *pNode = pLinkTable->pHead->pNext;
    while(pNode != NULL)
    {
        if(Condition(pNode))
        {
            return pNode;
        }
        pNode = pNode->pNext;
    }
    return NULL;
}

/*
 * get LinkTableHead
 */
tLinkNode* GetLinkTableFirst(tLinkTable *pLinkTable)
{
    if(pLinkTable == NULL)
    {
        printf("Not exist.\n");
        return NULL;
    }
    return pLinkTable->pHead->pNext;
}

/*
 * get next LinkTableNode
 */
tLinkNode* GetNextLinkNode(tLinkTable *pLinkTable, tLinkNode *pNode)
{
    if(pLinkTable == NULL || pNode == NULL)
    {
        printf("Not exist.\n");
        return NULL;
    }
    if(pLinkTable->linkNodeSize == 0)
    {
        printf("There is no node in this link table.\n");
        return NULL;
    }
    tLinkNode *pThisNode;
    pThisNode = pLinkTable->pHead->pNext;
    while(pThisNode != NULL)
    {
        if(pThisNode == pNode)
        {
            if(pThisNode == pLinkTable->pTail)
            {
                return NULL;
            }
            return pThisNode->pNext;
        }
        pThisNode = pThisNode->pNext;
    }
    return NULL;
}

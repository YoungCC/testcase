/**************************************************************************************************/
/* Copyright (C) SoftwareDesign@USTC, 2014                                                        */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  Caoyang                                                              */
/*  PRINCIPAL AUTHOR ID   :  JG14225028                                                           */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/29                                                           */
/*  DESCRIPTION           :  Interface of menu.c                                                  */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Caoyang, 2014/09/29
 *
 */


/*menu struct*/
typedef struct Menu tMenu;

/*create a menu*/
tMenu* CreateMenu();

/*add a command into menu*/
int AddCommand(tMenu *pMenu, char* pCom, char* pDesc, int (*handler)());

/*print all commands in menu on screen*/
int ShowAllCommand(tMenu *pMenu);

/*print all commands and their functions on screen*/
int ShowAllInformation(tMenu *pMenu);

/*start the menu program*/
void MenuStart(tMenu *Menu);

/*stop the menu program*/
int MenuStop(tMenu *pMenu);

/*delete command named pCommand*/
int DeleteCommand(tMenu *pMenu, char* pCom);

/*delete menu*/
int DeleteMenu(tMenu *pMenu);


/**************************************************************************************************/
/* Copyright (C) SoftwareDesign@USTC, 2014                                                        */
/*                                                                                                */
/*  FILE NAME             :  linktabe.h                                                           */
/*  PRINCIPAL AUTHOR      :  Caoyang                                                              */
/*  PRINCIPAL AUTHOR ID   :  JG14225028                                                           */
/*  SUBSYSTEM NAME        :  LinkTable                                                            */
/*  MODULE NAME           :  LinkTable                                                            */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/20                                                           */
/*  DESCRIPTION           :  interface of Link Table                                              */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Caoyang,2014/09/20
 *
 */

#ifndef _LINK_TABLE_H_
#define _LINK_TABLE_H_

#include <pthread.h>


/*
 * LinkTable Node Type
 */
typedef struct LinkNode
{
    struct LinkNode *pNext;
} tLinkNode;

/*
 * LinkTable Type
 */
typedef struct LinkTable
{
    tLinkNode *pHead;
    tLinkNode *pTail;
    int linkNodeSize;
} tLinkTable;

/*
 * Create a LinkTable
 */
tLinkTable* CreateLinkTable();
/*
 * Delete a LinkTable
 */
int DeleteLinkTable(tLinkTable *pLinkTable);
/*
 * Add a LinkTableNode to LinkTable
 */
int AddLinkNode(tLinkTable *pLinkTable, tLinkNode *pNode);
/*
 * Delete a LinkTableNode from LinkTable
 */
int DeleteLinkNode(tLinkTable *pLinkTable, tLinkNode *pNode);
/*
 * Search a LinkTableNode from LinkTable
 * int Conditon(tLinkTableNode * pNode);
 */
tLinkNode* SearchLinkNode(tLinkTable *pLinkTable, int Condition(tLinkNode *pNode));
/*
 * get LinkTableHead
 */
tLinkNode* GetLinkTableFirst(tLinkTable *pLinkTable);
/*
 * get next LinkTableNode
 */
tLinkNode* GetNextLinkNode(tLinkTable *pLinkTable, tLinkNode *pNode);

#endif /* _LINK_TABLE_H_ */


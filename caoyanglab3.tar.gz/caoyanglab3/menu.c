/**************************************************************************************************/
/* Copyright (C) SoftwareDesign@USTC, 2014                                                        */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  Caoyang                                                              */
/*  PRINCIPAL AUTHOR ID   :  JG14225028                                                           */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/29                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Caoyang, 2014/09/29
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include "menu.h"

#define CMD_MAX_LEN 128
#define SUCCESS 0
#define FAILURE -1

/*menu struct*/
struct Menu
{
    ;
};

/*create a menu*/
tMenu* CreateMenu()
{
    tMenu *p = (tMenu *)malloc(sizeof(tMenu));
    return p;
}

/*add a command into menu*/
int AddCommand(tMenu *pMenu, char* pCom, char* pDesc, int (*handler)())
{
    if(pMenu == NULL || pCom == NULL || pDesc == NULL)
    {
        return FAILURE;
    }
    printf("function...\n");
    return SUCCESS;   
}

/*print all commands and their functions on screen*/
int ShowAllInformation(tMenu *pMenu)
{
    if(pMenu == NULL)
    {
        return FAILURE;
    }
    printf("function...\n");
    return SUCCESS;
}

/*start the menu program*/
char pInputCmd[CMD_MAX_LEN];
void MenuStart(tMenu *pMenu)
{
    while(1)
    {
        if(pMenu == NULL)
        {
            printf("\nMenu start fail!\n");
            break;
        }
        printf("function...\n");
        break;
    } 
}

/*stop the menu program*/
int MenuStop(tMenu *pMenu)
{
    if(pMenu == NULL)
    {
        return FAILURE;
    }
    printf("function...\n");
    return SUCCESS;
}

/*delete command named pCom*/
int DeleteCommand(tMenu *pMenu, char* pCom)
{
    if(pMenu == NULL || pCom == NULL)
    {
        return FAILURE;
    }
    printf("function...\n");
    return SUCCESS;
}

/*delete menu*/
int DeleteMenu(tMenu *pMenu)
{
    if(pMenu == NULL)
    {
        return FAILURE;
    }
    printf("function...\n");
    return SUCCESS;
}

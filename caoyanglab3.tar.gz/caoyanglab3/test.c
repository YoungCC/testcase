/**************************************************************************************************/
/* Copyright (C) SoftwareDesign@USTC, 2014                                                        */
/*                                                                                                */
/*  FILE NAME             :  test.c                                                               */
/*  PRINCIPAL AUTHOR      :  Caoyang                                                              */
/*  PRINCIPAL AUTHOR ID   :  JG14225028                                                           */
/*  SUBSYSTEM NAME        :  test                                                                 */
/*  MODULE NAME           :  test                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/29                                                           */
/*  DESCRIPTION           :  This is a menu test program                                          */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Caoyang, 2014/09/29
 *
 */

#include <stdio.h>
#include "menu.h"

#define debug printf
#define SUCCESS 0
#define FAILURE -1

char* res[19];
int Result[19];

char* info[21] =
{
    "TestReport:",
    "CreateMenu[]",
    "AddCommand(null, null, null)",
    "AddCommand(tMenu, null, null)",
    "AddCommand(null, char*, null)",
    "AddCommand(null, null, char*)",
    "AddCommand(tMenu, char*, null)",
    "AddCommand(tMenu, null, char*)",
    "AddCommand(null, char*, char*)",
    "AddCommand(tMenu, char*, char*)",
    "ShowAllInformation(null)",
    "ShowAllInformation(tMenu)",
    "MenuStop(null)",
    "MenuStop(tMenu)",
    "DeleteCommand(null, null)",
    "DeleteCommand(null, char*)",
    "DeleteCommand(tMenu, null)",
    "DeleteCommand(tMenu, char*)",
    "DeleteMenu(null)",
    "DeleteMenu(tMenu)",
    "Testresult:"
};

int Help();
int GetVersion(tMenu *pMenu);

int main()
{
    /*initialize result array*/
    int i;
    for(i = 0; i < 19; i++)
    {
        Result[i] = 1;
        res[i] = "Not pass";
    }

    /*test return of CreateMenu()*/
    i = 0;
    debug("\n\033[;32mTest function of create menu:\033[0m\n");
    tMenu *createMenu = CreateMenu();
    if(createMenu == NULL)
    {
        debug("\nCreate menu fail!\n");
        Result[i++] = 1;
    }
    else
    {
        debug("\nCreate menu success!\n");
        res[i] = "Pass";
        Result[i++]  = 0;
    }

    /*test return of AddCommand (does not matter the 4th parameter is null or not null)*/
    debug("\n\033[;32mTest return of add command(no less than one null in parameters):\033[0m\n");
    char* pCom = "Test";
    char* pDesc = "Testing...";  
    int addCmd = AddCommand(NULL, NULL, NULL, Help);
    if(addCmd != FAILURE)
    {
        debug("\nAdd command %s success.\n", pCom);
        Result[i++] = 0;       
    }
    else
    {
        debug("\nAdd command %s fail.\n", pCom);
        res[i] = "Pass";
        i++;
    }   
    addCmd = AddCommand(createMenu, NULL, NULL, Help);
    if(addCmd != FAILURE)
    {
        debug("\nAdd command %s success.\n", pCom);
        Result[i++] = 0;
    }
    else
    {
        debug("\nAdd command %s fail.\n", pCom);
        res[i] = "Pass";
        i++;
    }    
    addCmd = AddCommand(NULL, pCom, NULL, Help);
    if(addCmd != FAILURE)
    {
        debug("\nAdd command %s success.\n", pCom);
    }
    else
    {
        debug("\nAdd command %s fail.\n", pCom);
        res[i] = "Pass";
        i++;
    } 
    addCmd = AddCommand(NULL, NULL, pDesc, Help);
    if(addCmd != FAILURE)
    {
        debug("\nAdd command %s success.\n", pCom);
        Result[i++] = 0;       
    }
    else
    {
        debug("\nAdd command %s fail.\n", pCom);
        res[i] = "Pass";
        i++;
    } 
    addCmd = AddCommand(createMenu, pCom, NULL, Help);
    if(addCmd != FAILURE)
    {
        debug("\nAdd command %s success.\n", pCom);
        Result[i++] = 0;       
    }
    else
    {
        debug("\nAdd command %s fail.\n", pCom);
        res[i] = "Pass";
        i++;
    } 
    addCmd = AddCommand(createMenu, NULL, pDesc, Help);
    if(addCmd != FAILURE)
    {
        debug("\nAdd command %s success.\n", pCom);
        Result[i++] = 0;       
    }
    else
    {
        debug("\nAdd command %s fail.\n", pCom);
        res[i] = "Pass";
        i++;
    } 
    addCmd = AddCommand(NULL, pCom, pDesc, Help);
    if(addCmd != FAILURE)
    {
        debug("\nAdd command %s success.\n", pCom);
        Result[i++] = 0;       
    }
    else
    {
        debug("\nAdd command %s fail.\n", pCom);
        res[i] = "Pass";
        i++;
    } 
    debug("\n\033[;32mTest function of add command(correct parameters):\033[0m\n");
    AddCommand(createMenu, "help", "This command shows all commands!", ShowAllInformation);
    AddCommand(createMenu, "version", "This command shows version informations!", GetVersion);
    AddCommand(createMenu, "exit", "This command exits the menu!", MenuStop);
    if(addCmd == FAILURE)
    {
        debug("\nAdd command %s success.\n", pCom);
        res[i] = "Pass";
        Result[i++] = 0;       
    }
    else
    {
        debug("\nAdd command %s fail.\n", pCom);
        i++;
    } 
 
    /*test return of ShowAllInformation(tMenu *pMenu)*/
    debug("\n\033[;32mTest return of show information(no less than one null in parameters):\033[0m\n");
    int showInfo = ShowAllInformation(NULL);
    if(showInfo != FAILURE)
    {
        debug("\nShow all information success.\n");
        Result[i++] = 0;
    }
    else
    {
        debug("\nShow all information fail.\n");
        res[i] = "Pass";
        i++;
    }
    debug("\n\033[;32mTest function of show information(correct parameters):\033[0m\n");
    showInfo = ShowAllInformation(createMenu);
    if(showInfo == SUCCESS)
    {
        debug("\nShow all information success.\n");
        res[i] = "Pass";
        Result[i++] = 0;
    }
    else
    {
        debug("\nShow all information fail.\n");
        i++;
    }
    debug("\n\033[;32mTest function of menu start:\033[0m\n");
    MenuStart(createMenu);

    /*test return of MenuStop(tMenu *pMenu)*/
    debug("\n\033[;32mTest return of menu stop(no less than one null in parameters):\033[0m\n");
    int menuStop = MenuStop(NULL);
    if(menuStop != FAILURE)
    {
        debug("\nmenu stop success.\n");
        Result[i++] = 0;
    }
    else
    {
        debug("\nmenu stop fail.\n");
        res[i] = "Pass";
        i++;
    }
    debug("\n\033[;32mTest function of menu stop(correct parameters):\033[0m\n");
    menuStop = MenuStop(createMenu);
    if(menuStop == SUCCESS)
    {
        debug("\nmenu stop success.\n");
        res[i] = "Pass";
        Result[i++] = 0;
    }
    else
    {
        debug("\nmenu stop fail.\n");
        i++;
    }

    /*test return of DeleteCommand(tMenu *pMenu, char* pCommand)*/
    debug
    ("\n\033[;32mTest return of delete command(no less than one null in parameters):\033[0m\n");
    int deleteCmd = DeleteCommand(NULL, NULL);
    if(deleteCmd != FAILURE)
    {
        debug("\nDelete command success.\n");
        Result[i++] = 0;
    }
    else
    {
        debug("\nDelete command fail.\n");
        res[i] = "Pass";
        i++;
    }
    deleteCmd = DeleteCommand(NULL, pCom);
    if(deleteCmd != FAILURE)
    {
        debug("\nDelete command success.\n");
        Result[i++] = 0;
    }
    else
    {
        debug("\nDelete command fail.\n");
        res[i] = "Pass";
        i++;
    }
    deleteCmd = DeleteCommand(createMenu, NULL);
    if(deleteCmd != FAILURE)
    {
        debug("\nDelete command success.\n");
        Result[i++] = 0;
    }
    else
    {
        debug("\nDelete command fail.\n");
        res[i] = "Pass";
        i++;
    }
    debug("\n\033[;32mTest function of delete command(correct parameters):\033[0m\n");
    deleteCmd = DeleteCommand(createMenu, "version");
    if(deleteCmd == SUCCESS)
    {
        debug("\nDelete command success.\n");
        res[i] = "Pass";
        Result[i++] = 0;
    }
    else
    {
        debug("\nDelete command fail.\n");
        i++;
    }
    debug("\n\033[;32mShow all command information after deleting command:\033[0m\n");
    ShowAllInformation(createMenu);

    /*test return of DeleteMenu(tMenu *pMenu)*/
    debug("\n\033[;32mTest return of delete menu(no less than one null in parameters):\033[0m\n");
    int deleteMenu = DeleteMenu(NULL);
    if(deleteMenu != FAILURE)
    {
        debug("\nDelete menu success.\n");
        Result[i++] = 0;
    }
    else
    {
        debug("\nDelete menu fail.\n");
        res[i] = "Pass";
        i++;
    }
    debug("\n\033[;32mTest function of delete menu(correct parameters):\033[0m\n");
    deleteMenu = DeleteMenu(createMenu);
    if(deleteMenu == SUCCESS)
    {
        debug("\nDelete menu success.\n");
        res[i] = "Pass";
        Result[i++] = 0;
    }
    else
    {
        debug("\nDelete menu fail.\n");
        i++;
    }
    debug("\n\033[;32mShow all command information after deleting menu:\033[0m\n");
    ShowAllInformation(createMenu);

    /*print the result*/
    printf("\n\033[;32m%s\033[0m\n", info[0]);
    for(i = 0; i < 19; i++)
    {
        if(Result[i] == 1)
        {
            printf("Testcase %s\n%s\n\n", info[i+1], "Failure");               
        }
        else
        {
            printf("Testcase %s\n%s\n\n", info[i+1], "Success");
        }
    }
    printf("\n\033[;32m%s\033[0m\n", info[20]);
    for(i = 0; i < 19; i++)
    {
        printf("Testcase %s: %s\n\n", info[i+1], res[i]);
    }
    return 0;
}

int GetVersion(tMenu *pMenu)
{
    printf("The version is v1.0\n");
    return 0;
}

int Help()
{
}

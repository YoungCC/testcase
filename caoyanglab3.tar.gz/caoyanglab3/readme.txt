
This program includes two test stubs:menu.c is a test stub that is non-functional, but function.c is functional.

Build Procedure:

        You can use "make" to compile menu.c and test.c                          
	$ make

        You can use "make exp" to compile function.c test.c and linkTable.c 
	$ make exp
	
	You can use "make run" to run test.c
	$ make run

	You can use "make clean" to clean all .o file
	$ make clean


